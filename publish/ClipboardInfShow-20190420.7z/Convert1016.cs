using System;
using System.Text.RegularExpressions;
class Convert1016
{
    Regex r10 = new Regex("^[0-9]+$");
    Regex r16 = new Regex("^(0x|0X)?[0-9a-fA-F]+$");
    public string Convert(string input)
    {
        string output = input;
        if (!string.IsNullOrEmpty(input))
        {
            input = input.Trim();
            if (r10.IsMatch(input))
            {
                long i = long.Parse(input);
                long i16 = long.Parse(input, System.Globalization.NumberStyles.HexNumber);
                output = string.Format("{0} <-> 0x{0:X}\r\n{1} <-> 0x{1:X}", i, i16);
            }
            else if (r16.IsMatch(input))
            {
                if (input.StartsWith("0x") || input.StartsWith("0X")) input = input.Substring(2);
                long i16 = long.Parse(input, System.Globalization.NumberStyles.HexNumber);
                output = string.Format("{0} <-> 0x{0:X} ", i16);
            }
            return output;
        }
        else
        {
            return null;
        }
        
    }
}