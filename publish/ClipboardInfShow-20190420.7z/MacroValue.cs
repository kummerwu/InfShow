using System;
using System.Collections;
using System.Text.RegularExpressions;
using System.IO;
class MacroValue
{
    static Hashtable hashtable = null;
    public static void Load()
    {
        if(hashtable == null)
        {
            hashtable = new Hashtable();
            string[] lns = File.ReadAllLines(@"C:\Users\kumme\source\repos\InfShow\InfShow\bin\Debug\mv.txt");
            foreach(string ln in lns)
            {
                string[] tokes = ln.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                foreach(string t in tokes)
                {
                    string old = hashtable[t] as string;
                    if(old!=null)
                    {
                        hashtable.Remove(t);
                    }
                    hashtable.Add(t, old == null ? ln : old + "\n" + ln);
                }

            }
        }
    }
    public string Convert(string input)
    {
        Load();
        if (input != null)
        {
            return hashtable[input.Trim()] as string;
        }
        else
        {
            return null;
        }
        
    }
}