using System;
using System.Text.RegularExpressions;
class TestMsg
{
    
    public string Convert(string input)
    {
        string output = input;
       return output+"kummer";
        
    }
}